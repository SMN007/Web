<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
<title>Play Quiz</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
 
    <meta property="og:title" content="Answer 4 Qustion's Win 400  Rs Paytm">
    <meta property="og:description" content="Free Recharge And Free Paytm Cash"> 
    <meta property="og:url" content="no link ">
    <meta property="og:site_name" content="Play Quiz And Earn 400 Rs Paytm">
    <meta property="og:image" content="offer200.png">

<link rel="stylesheet" type="text/css" href="bootstrap.min.css" />
 
</head>
<center><div class="row" style="color:white;font: 100 0.3em/1 Oswald, sans-serif;line-height:1.5;font-weight:bold;">
    insurance, Electricity, Gas, Attorney, Mortgage, Claim, Loans  Car Insurance , Loans , Car Loans, Educational ,Degree , Software , Hosting , Home Loans , Adword electricity , Loans , Credit, Donate ,Call Trading , Recovery , Mortgage , Attorney , Lawyer Gas , Claim , Conference , Cord ,Treatment , Transfer , Life , Attorney , Blood </div>
<body class="clear header_fixed sidebar_fixed has_sidebar">

<div class="clear wrap fixed_width">


    <header>
    <div class="h_logo">

    </div>
    <h1>Congratulation </h1>	
</header>
<center>

</center>
<!-- CONTAINER : STARTS -->    <section class="main_container fbg">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Responsive1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2920596594941708"
     data-ad-slot="6470739230"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<div class="ril-step adtop" >         <span class="s-padding">Instructions </span>            <p class="s-padding">By answering only 4 questions you can win 400 rupees recharge and paytm cash.</p>            <p class="s-padding">                If any of your answers are wrong, you will not receive any reward.!            </p>        <p class="s-padding">       </p>                     </div>
      <div class="form-step">
            <form method="post" action="invite.php" id="submitForm">
               
<label>Select Size <font color="red">*</font></label>
                <select name="state" class="state" id="state" required>
                     <option value="0">Select Operator</option> <option value="1">Airtel</option><option value="2">Idea</option><option value="3">Vodafone</option><option value="4">Jio</option><option value="5">BSNL</option><option value="6">Telenor</option><option value="7">MTS</option><option value="8">Aircel</option></select>
				<span class="error" id="errorState"></span>
                <label>Select Your State<font color="red">*</font></label>
                <select name="state" class="state" id="state" required>
                    <option value="">Select State</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Puducherry">Puducherry</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option></select>
				<span class="error" id="errorState"></span>
				
                <label>Mobile No.<font color="red">*</font></label>
                <input name="mobile" class="textbox1" type="number"  id="mobile" maxlength="10" placeholder="Enter Your Mobile Number"
				required>
				<span class="error"  id="errorMobile"></span>
    <div class="ai-node-body-top-banner" style="margin-bottom:1em;">


    </div>

                <input class="button" type="submit" value="SUBMIT">
                     
                
            </form>
        </div>

    </section>
    <!-- CONTAINER : ENDS -->
   

    <footer class="footer">
 <div class="row" style="color:black;font: 100 1.3em/1 Oswald, sans-serif;line-height:1.5;font-weight:bold;">
     Terms & Condition
</footer>    


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Responsive1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2920596594941708"
     data-ad-slot="6470739230"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<!-- WRAP : ENDS -->
<center><div class="row" style="color:black;font: 100 0.3em/1 Oswald, sans-serif;line-height:1.5;font-weight:bold;">
What Blockchain and Bitcoin Mean for the Protection Business 

You may have heard the expressions "blockchain" or "Bitcoin" utilized as a part of tech hovers in the course of recent years. These ideas, alongside intense utilize cases, are changing how we consider money, exchanges and contracts. Simultaneously, they're likewise changing how we consider the protection business. 

These progressions will affect protection bearers and operators, and how protection is purchased and sold. That implies understanding blockchain and Bitcoin is essential in case you're hoping to win in the cutting edge protection industry. This post has you secured. It gives meanings of blockchain and Bitcoin, at that point separates why this data is critical to protection industry experts. 

WHAT IS BLOCKCHAIN? WHAT IS BITCOIN? 

In their book Blockchain Upheaval, Wear and Alex Tapscott clarify that blockchain is "the brilliantly straightforward, progressive convention that enables exchanges to be at the same time mysterious and secure by keeping up a sealed open record of significant worth." 

The blockchain is intended to store exchange records ("obstructs") in numerous spots, connected to each other (henceforth the "chain" some portion of the name) and straightforward to any client who wishes to see them. Critically, this record can't be changed, so anybody can see a typical and exact rundown of authentic exchanges. 

Bitcoin is a kind of computerized money that utilizations blockchain innovation. It's not by any means the only one that utilizations blockchain, yet is one of the more prevalent alternatives available. Despite the fact that bitcoin is the most famous cryptographic money upheld by blockchain innovation, other advanced monetary forms, for example, ether and litecoin—utilize blockchain innovation too. 

All bitcoin exchanges are recorded in a decentralized open record that can't be adjusted. In principle, this is something worth being thankful for on the grounds that it makes trust among all gatherings of the exchange and gives an unmistakable trail of procurement that avoids fake exchanges. 

This is one manner by which blockchain can possibly change exchanges. However, remember that blockchain does not need to be money related. 

Ramifications OF BLOCKCHAIN AND BITCOIN FOR THE Protection Business 

Blockchain applications like cryptocurency, shrewd contracts and decentralized models for protection will change how protection is appropriated. What's more, when you change how protection is disseminated, you significantly modify how existing players profit and test business as usual. 

Insurance agencies could utilize the blockchain to make a disseminated record that cultivates straightforwardness, successfully tracks cases and exchange history, and gives perceivability into the authenticity of a claim. Brilliant contracts based on the blockchain can balance deceitful claims by recording exchange history on people in general system, which would dismiss different cases for a similar occasion. This could spare the business billions and open up gigantic chances to make huge measures of significant worth for buyers. 

Cryptocurriencies can make trust amongst safety net providers and their clients could make trust. For example, INGUARD was the principal insurance agency to acknowledge bitcoin installments. We did this since it was the correct activity for our well informed clients—a state of mind very rare in the protection business today. 

Consider: 40% of protection premiums turn over every year—and 66% of buyers would purchase protection on the web in the event that they could. (What's more, and, after its all said and done, they're scarcely happy with back up plan sites.) Shoppers don't confide in their safety net providers to put their best advantages on the most fundamental level or execute in a reasonable, break even with way. 

Bitcoin and blockchain innovation, as we would see it, are devices that can possibly carefully ensure customers, as well as reestablish assume that their needs are being met. Innovation appropriation in the protection business ought to dependably make more an incentive for shoppers. It should expel contact from the purchasing procedure and empower a superior client encounter. What's more, its adequacy ought to be estimated by consumer loyalty, not the amount PR or advertising duplicate another framework creates. 

That doesn't generally happen. In any case, with the focal points blockchain innovation gives, that could begin to change. Also, that will be advance in reality.

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</div>
<!-- WRAP : ENDS -->
</body>
<script>
$(function(){
		
		$('document').on('click','#submitFrm',function(event){
			event.preventDefault()
			var validFlag = true;
			var state	=	$('#state option:selected').val();
			var mobile	=	$.trim($('#mobile').val());
			var email	=	$.trim($('#email').val());
		    if (email=="") 
		    {
		        $('#errorEmail').text("Email is required");
		        $('#email').val("");
		        validFlag =  false;
		    }
		    else if (!email.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)) 
		    {
		        $('#errorEmail').text("You have provided an invalid email");
				$('#email').val("");
		        validFlag =  false;
		    }
		    else
			{
				$('#errorEmail').text("");
			}
			if (!mobile.match(/^\d+$/)) 
		    {
		        $('#errorMobile').text("Mobile is required");
			   $('#mobile').val("");
		        validFlag =  false;
		    }
			else if (mobile.length != 10) 
		    {
		        $('#errorMobile').text("You have provided an invalid  mobile");
				$('#mobile').val("");
		        validFlag =  false;
		    }
			else
			{
				$('#errorMobile').text("");
			}
			if(state == "0") 
			{
				$('#errorState').text("State is required");
		        validFlag =  false;
			}
			else
			{
				$('#errorState').text("");
			}
			if(validFlag){
				$("#submitForm").submit();
			}
		});
	});
</script>
</html>